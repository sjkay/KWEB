function btn1() {
	// body...
}

function btn2() {
	// body...
}

function btn3() {
	// body...

}

function initBoxes() {
	// body...
}