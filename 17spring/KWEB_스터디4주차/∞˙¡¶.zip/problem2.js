var danCheck = /^[1-9]{1}$/;

/*

>>How to check the input<<
danCheck.test(input)
[input: number]

return: true 	(if input is a number between 1 and 9)
		false	(otherwise)

ex.
input	|return
--------|--------
1       |true
"1"     |false
12      |flase
8       |true
"abc"   |flase

*/


function myFunc1() {
	// body...
}

function myFunc2() {
	// body...
}

function clearTable() {
	var timesTable = document.getElementById('timesTable');

	timesTable.innerHTML = 'Change here!!';
}